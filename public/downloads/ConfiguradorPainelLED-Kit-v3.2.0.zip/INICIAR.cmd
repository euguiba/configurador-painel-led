@echo off
setlocal EnableDelayedExpansion
title GLOBAL LED EXPERIENCE - Configurador de Notebook
cd /d "%~dp0"

:: =====================================================================
::  INICIAR.cmd - unico arquivo de inicializacao do pendrive
::  1) Configurar este notebook (abre a interface como administrador)
::  2) Pular a configuracao inicial do Windows 11 (OOBE)
:: =====================================================================

set "raiz=%~dp0"
set "script=%raiz%ConfiguradorPainelLED.ps1"

if exist "%script%" goto :temScript

echo  Procurando a particao do pendrive com o configurador...
for %%D in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    if exist "%%D:\ConfiguradorPainelLED.ps1" (
        set "raiz=%%D:\"
        set "script=%%D:\ConfiguradorPainelLED.ps1"
        goto :temScript
    )
)

echo.
echo  Nao encontrei o arquivo ConfiguradorPainelLED.ps1.
echo  Extraia o kit ZIP na RAIZ do pendrive e abra o INICIAR.cmd
echo  que fica na mesma pasta do ConfiguradorPainelLED.ps1.
echo.
pause
exit /b 1

:temScript
cls
echo.
echo  ==================================================
echo   GLOBAL LED EXPERIENCE - CONFIGURADOR DE NOTEBOOK
echo  ==================================================
echo.
echo   Configurador encontrado em: %raiz%
echo.
echo   [1] Configurar este notebook  (padrao)
echo   [2] Pular a configuracao inicial do Windows (OOBE)
echo.
choice /C 12 /T 5 /D 1 /N /M "  Escolha (1 ou 2), inicia sozinho em 5s: "
if errorlevel 2 goto :oobe
goto :configurar

:oobe
echo.
echo  ==================================================
echo   PULAR A CONFIGURACAO INICIAL DO WINDOWS 11
echo  ==================================================
echo.
echo  Criando a conta local "Global" (administrador, sem senha)...
net user Global /add >nul 2>&1
net user Global /active:yes >nul 2>&1
net localgroup Administradores Global /add >nul 2>&1
net localgroup Administrators Global /add >nul 2>&1

net user Global >nul 2>&1
if errorlevel 1 goto :oobeManual

echo  Ligando o logon automatico da conta Global...
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v AutoAdminLogon /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultUserName /t REG_SZ /d Global /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultPassword /t REG_SZ /d "" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultDomainName /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Lsa" /v LimitBlankPasswordUse /t REG_DWORD /d 0 /f >nul 2>&1

echo  Desligando as telas restantes de configuracao...
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OOBE" /v BypassNRO /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OOBE" /v SkipMachineOOBE /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OOBE" /v SkipUserOOBE /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OOBE" /v LaunchUserOOBE /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OOBE" /v DisableVoice /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OOBE" /v DisablePrivacyExperience /t REG_DWORD /d 1 /f >nul 2>&1

:: Perfil padrao (vale para a conta Global no primeiro logon)
reg load HKU\GLOBAL_DEFAULT "C:\Users\Default\NTUSER.DAT" >nul 2>&1
for %%K in (GLOBAL_DEFAULT .DEFAULT) do (
    reg add "HKU\%%K\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-338389Enabled /t REG_DWORD /d 0 /f >nul 2>&1
    reg add "HKU\%%K\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-310093Enabled /t REG_DWORD /d 0 /f >nul 2>&1
    reg add "HKU\%%K\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement" /v ScoobeSystemSettingEnabled /t REG_DWORD /d 0 /f >nul 2>&1
    reg add "HKU\%%K\Software\Policies\Microsoft\Windows\WindowsCopilot" /v TurnOffWindowsCopilot /t REG_DWORD /d 1 /f >nul 2>&1
)
reg unload HKU\GLOBAL_DEFAULT >nul 2>&1

echo  Marcando a configuracao inicial como concluida...
reg add "HKLM\SYSTEM\Setup" /v SetupType /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SYSTEM\Setup" /v SystemSetupInProgress /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SYSTEM\Setup" /v OOBEInProgress /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SYSTEM\Setup" /v CmdLine /t REG_SZ /d "" /f >nul 2>&1
reg add "HKLM\SYSTEM\Setup\Status\ChildCompletion" /v setup.exe /t REG_DWORD /d 3 /f >nul 2>&1
reg add "HKLM\SYSTEM\Setup\Status\SysprepStatus" /v GeneralizationState /t REG_DWORD /d 7 /f >nul 2>&1
reg add "HKLM\SYSTEM\Setup\Status\SysprepStatus" /v CleanupState /t REG_DWORD /d 2 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Setup\OOBE" /v UnattendCreatedUser /t REG_DWORD /d 1 /f >nul 2>&1

echo.
echo  Tudo pronto. O notebook vai reiniciar e entrar direto na area
echo  de trabalho da conta Global (sem senha, sem perguntas).
echo.
timeout /t 5 /nobreak >nul
shutdown /r /t 0
exit /b 0


:oobeManual
echo.
echo  Nao consegui criar a conta local neste estagio do Windows.
echo  Aplicando o modo de configuracao com conta local...
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OOBE" /v BypassNRO /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OOBE" /v DisablePrivacyExperience /t REG_DWORD /d 1 /f >nul 2>&1
start "" ms-cxh:localonly
echo.
echo  Se abriu a tela de criacao de usuario, use o nome Global (sem senha),
echo  conclua nela e depois volte a abrir este INICIAR.cmd na opcao 1.
echo.
echo  Se nada abriu, pressione R para reiniciar. Depois do reinicio
echo  escolha "Nao tenho internet" e "Continuar limitado".
echo.
choice /C RS /N /M "  [R] Reiniciar  [S] Sair: "
if errorlevel 2 exit /b 0
shutdown /r /t 3 /c "Reiniciando para liberar a configuracao local do Windows"
exit /b 0


:configurar
echo.
echo  Liberando os arquivos do pendrive...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%raiz%' -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue"
echo  Abrindo o tutorial no navegador...
start "" "https://confignote-automatico.lovable.app"
echo  Abrindo a interface... aceite o aviso do Windows clicando em SIM.
echo.
cd /d "%raiz%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList '-NoProfile -ExecutionPolicy Bypass -STA -File \"%script%\"'"
if errorlevel 1 (
  echo.
  echo  Houve um erro ao abrir. Tire um print desta tela e avise o suporte.
  pause
)
exit /b 0
