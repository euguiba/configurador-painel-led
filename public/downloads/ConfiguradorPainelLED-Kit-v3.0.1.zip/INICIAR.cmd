@echo off
setlocal EnableDelayedExpansion
title GLOBAL LED EXPERIENCE - Configurador de Notebook
cd /d "%~dp0"

:: =====================================================================
::  INICIAR.cmd - unico arquivo de inicializacao do pendrive
::  1) Configurar este notebook (abre a interface como administrador)
::  2) Pular a configuracao inicial do Windows 11 (OOBE)
:: =====================================================================

set "raiz=%~dp0"
set "script=%raiz%ConfiguradorPainelLED.ps1"

if exist "%script%" goto :temScript

echo  Procurando a particao do pendrive com o configurador...
for %%D in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    if exist "%%D:\ConfiguradorPainelLED.ps1" (
        set "raiz=%%D:\"
        set "script=%%D:\ConfiguradorPainelLED.ps1"
        goto :temScript
    )
)

echo.
echo  Nao encontrei o arquivo ConfiguradorPainelLED.ps1.
echo  Extraia o kit ZIP na RAIZ do pendrive e abra o INICIAR.cmd
echo  que fica na mesma pasta do ConfiguradorPainelLED.ps1.
echo.
pause
exit /b 1

:temScript
cls
echo.
echo  ==================================================
echo   GLOBAL LED EXPERIENCE - CONFIGURADOR DE NOTEBOOK
echo  ==================================================
echo.
echo   Configurador encontrado em: %raiz%
echo.
echo   [1] Configurar este notebook  (padrao)
echo   [2] Pular a configuracao inicial do Windows (OOBE)
echo.
choice /C 12 /T 5 /D 1 /N /M "  Escolha (1 ou 2), inicia sozinho em 5s: "
if errorlevel 2 goto :oobe
goto :configurar

:oobe
echo.
echo  ==================================================
echo   PULAR A CONFIGURACAO INICIAL DO WINDOWS 11
echo  ==================================================
echo.
echo  Aplicando o modo de configuracao com conta local...
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OOBE" /v BypassNRO /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OOBE" /v DisablePrivacyExperience /t REG_DWORD /d 1 /f >nul 2>&1

echo  Tentando abrir a tela oficial de conta local...
start "" ms-cxh:localonly

echo.
echo  Se abriu a tela de criacao de usuario, conclua nela e depois
echo  volte a abrir este INICIAR.cmd e escolha a opcao 1.
echo.
echo  Se nada abriu, pressione R para reiniciar. Depois do reinicio
echo  escolha "Nao tenho internet" e "Continuar limitado".
echo.
choice /C RS /N /M "  [R] Reiniciar  [S] Sair: "
if errorlevel 2 exit /b 0
shutdown /r /t 3 /c "Reiniciando para liberar a configuracao local do Windows"
exit /b 0

:configurar
echo.
echo  Liberando os arquivos do pendrive...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%raiz%' -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue"
echo  Abrindo o tutorial no navegador...
start "" "https://confignote-automatico.lovable.app"
echo  Abrindo a interface... aceite o aviso do Windows clicando em SIM.
echo.
cd /d "%raiz%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList '-NoProfile -ExecutionPolicy Bypass -STA -File \"%script%\"'"
if errorlevel 1 (
  echo.
  echo  Houve um erro ao abrir. Tire um print desta tela e avise o suporte.
  pause
)
exit /b 0
